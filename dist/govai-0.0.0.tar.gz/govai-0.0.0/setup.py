from setuptools import setup

setup(name='govai',
      version='0.0.0',
      description='ML Library',
      url='http://github.com/INF800/govai',
      author='Asapanna Rakesh',
      author_email='rakeshark22@gmail.com',
      license='Apache v2',
      packages=['govai'],
      zip_safe=False)