### Insatallation

Install locally with sym-link for fast code updates
```
pip install -e .
```

